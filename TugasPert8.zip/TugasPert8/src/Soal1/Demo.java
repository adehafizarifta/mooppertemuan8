package Soal1;

import java.util.Scanner;

public class Demo {
	
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		int angka;
		
		System.out.println("Masukkan integer : ");
		angka = scan.nextInt();scan.nextLine();
		MyClassGanjilGenap myClassGanjilGenap = new MyClassGanjilGenap(angka);
		Thread thread = new Thread(myClassGanjilGenap);
		thread.start();

		MyClassFibonacci myClassFibonacci = new MyClassFibonacci(angka);
		Thread thread2 = new Thread(myClassFibonacci);
		thread2.start();

	}

}
