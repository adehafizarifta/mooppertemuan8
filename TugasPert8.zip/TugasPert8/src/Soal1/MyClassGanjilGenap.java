package Soal1;

public class MyClassGanjilGenap implements Runnable {
	
	int angka;
	
	public MyClassGanjilGenap(int angka) {
		System.out.println("Silahkan tunggu 30 detik untuk hasil genap ganjil");
		this.angka = angka;
	}


	@Override
	public void run() {
		try {
			Thread.sleep(30000);
			if(angka %2 == 1){
				System.out.println("Ganjil");
			}
			else{
				System.out.println("Genap");
			}
		} catch (InterruptedException e) {
		}
	}
	


}
